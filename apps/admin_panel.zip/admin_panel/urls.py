"""CuraSuite — Admin Panel URLs  (mounted at /manage/)"""
from django.urls import path
from . import views

app_name = "admin_panel"

urlpatterns = [
    # Auth
    path("login/",                views.admin_login,           name="login"),
    path("logout/",               views.admin_logout,          name="logout"),

    # Dashboard
    path("",                      views.dashboard,             name="dashboard"),

    # CRM
    path("crm/leads/",            views.crm_leads,             name="crm_leads"),
    path("crm/leads/<uuid:pk>/",  views.crm_lead_detail,       name="crm_lead_detail"),

    # Content
    path("pages/",                views.pages_list,            name="pages_list"),
    path("blogs/",                views.blogs_list,            name="blogs_list"),

    # Newsletter
    path("newsletter/",           views.newsletter_subscribers,name="newsletter"),

    # Settings
    path("settings/",             views.site_settings,         name="settings"),
]
