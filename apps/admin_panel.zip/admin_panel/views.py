"""CuraSuite — Admin Panel Views"""
import logging
from django.contrib.auth import authenticate, login, logout
from django.http import JsonResponse
from django.shortcuts import redirect, render
from django.views.decorators.http import require_POST

from .decorators import admin_required
from .forms import AdminLoginForm
from .selectors import (
    get_dashboard_stats, get_leads_by_source, get_leads_by_status,
    get_recent_demo_requests, get_recent_leads,
)

logger = logging.getLogger(__name__)


# ── Auth ───────────────────────────────────────────────────────────────────────

def admin_login(request):
    if request.user.is_authenticated and request.user.is_staff:
        return redirect("admin_panel:dashboard")

    error = None
    form  = AdminLoginForm(request.POST or None)

    if request.method == "POST" and form.is_valid():
        user = authenticate(
            request,
            username=form.cleaned_data["email"],
            password=form.cleaned_data["password"],
        )
        if user and user.is_staff:
            login(request, user)
            if not form.cleaned_data.get("remember_me"):
                request.session.set_expiry(0)
            logger.info("Admin login: %s", user.email)
            next_url = request.GET.get("next", "/manage/")
            return redirect(next_url)
        error = "Invalid email or password, or insufficient permissions."

    return render(request, "admin_panel/auth/login.html", {"form": form, "error": error})


def admin_logout(request):
    logout(request)
    return redirect("admin_panel:login")


# ── Dashboard ──────────────────────────────────────────────────────────────────

@admin_required
def dashboard(request):
    stats  = get_dashboard_stats()
    leads  = get_recent_leads()
    demos  = get_recent_demo_requests()
    by_status = get_leads_by_status()
    by_source = get_leads_by_source()
    return render(request, "admin_panel/dashboard/index.html", {
        "stats":     stats,
        "leads":     leads,
        "demos":     demos,
        "by_status": by_status,
        "by_source": by_source,
        "page_title": "Dashboard",
        "active_nav": "dashboard",
    })


# ── CRM ────────────────────────────────────────────────────────────────────────

@admin_required
def crm_leads(request):
    from apps.crm.models import Lead
    from apps.crm.selectors import get_all_leads

    status_filter = request.GET.get("status", "")
    search        = request.GET.get("q", "").strip()

    leads = Lead.objects.select_related("assigned_to").order_by("-created_at")
    if status_filter:
        leads = leads.filter(status=status_filter)
    if search:
        leads = leads.filter(email__icontains=search) | leads.filter(full_name__icontains=search)

    from django.core.paginator import Paginator
    paginator = Paginator(leads, 20)
    page      = paginator.get_page(request.GET.get("page", 1))

    return render(request, "admin_panel/crm/leads.html", {
        "leads":         page,
        "status_filter": status_filter,
        "search":        search,
        "lead_statuses": Lead.Status.choices,
        "page_title":    "Leads",
        "active_nav":    "crm",
    })


@admin_required
def crm_lead_detail(request, pk):
    from apps.crm.selectors import get_lead_with_history
    lead = get_lead_with_history(pk)
    if not lead:
        from django.http import Http404
        raise Http404
    return render(request, "admin_panel/crm/lead_detail.html", {
        "lead":       lead,
        "page_title": lead.full_name,
        "active_nav": "crm",
    })


# ── Pages ──────────────────────────────────────────────────────────────────────

@admin_required
def pages_list(request):
    from apps.pages.models import Page
    pages = Page.all_objects.filter(deleted_at__isnull=True).order_by("slug")
    return render(request, "admin_panel/pages/list.html", {
        "pages": pages, "page_title": "Pages", "active_nav": "pages",
    })


# ── Blogs ──────────────────────────────────────────────────────────────────────

@admin_required
def blogs_list(request):
    from apps.blogs.models import Blog
    blogs = Blog.all_objects.filter(deleted_at__isnull=True).select_related("author", "category").order_by("-created_at")
    return render(request, "admin_panel/blogs/list.html", {
        "blogs": blogs, "page_title": "Blog Posts", "active_nav": "blogs",
    })


# ── Newsletter ─────────────────────────────────────────────────────────────────

@admin_required
def newsletter_subscribers(request):
    from apps.newsletter.models import NewsletterSubscriber
    subs = NewsletterSubscriber.objects.order_by("-created_at")
    return render(request, "admin_panel/settings/newsletter.html", {
        "subscribers": subs, "page_title": "Subscribers", "active_nav": "newsletter",
    })


# ── Settings ───────────────────────────────────────────────────────────────────

@admin_required
def site_settings(request):
    from apps.integrations.models import SiteSettings
    settings = SiteSettings.load()

    if request.method == "POST":
        # Update fields from POST
        fields = [
            "ga4_measurement_id", "gtm_container_id", "meta_pixel_id", "clarity_project_id",
            "whatsapp_phone", "whatsapp_message", "whatsapp_tooltip",
            "chatbot_name", "chatbot_greeting", "chatbot_system_prompt",
            "captcha_site_key", "captcha_provider",
        ]
        bool_fields = ["whatsapp_enabled", "chatbot_enabled", "captcha_enabled"]

        for field in fields:
            if field in request.POST:
                setattr(settings, field, request.POST[field])
        for field in bool_fields:
            setattr(settings, field, field in request.POST)

        settings.save()

        if request.headers.get("HX-Request"):
            return render(request, "admin_panel/components/alert.html", {
                "type": "success", "message": "Settings saved successfully.",
            })
        return redirect("admin_panel:settings")

    return render(request, "admin_panel/settings/index.html", {
        "settings": settings, "page_title": "Site Settings", "active_nav": "settings",
    })
